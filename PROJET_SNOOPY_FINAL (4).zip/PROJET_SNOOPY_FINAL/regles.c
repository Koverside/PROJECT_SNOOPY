#include "header.h"

void Regles()
{
    int a=0;
    printf("Regles du jeu :\n");
    printf("---------------------------------------------------------------------\n");
    printf("-Snoopy est un chien qui doit collecter 4 oiseaux dans chaque niveau.\n");
    printf("-Il doit eviter d'etre touche par la balle ou les ennemis, s'ils sont presents.\n");
    printf("-Le jeu comporte plusieurs niveaux de difficulte croissante.\n");
    printf("-Chaque niveau doit etre termine en moins de 120 secondes.\n");
    printf("-Si le temps est ecoule, le joueur perd une vie et recommence le niveau.\n");
    printf("-Snoopy peut se deplacer vers le haut, le bas, la gauche et la droite.\n");
    printf("-La balle se deplace en diagonale et rebondit sur les murs du niveau.\n");
    printf("-Snoopy ne peut pas sortir du niveau.\n");
    printf("-Gagnez en recuperant les 4 oiseaux. Une fois le niveau termine, le suivant commence.\n");
    printf("-Le jeu se termine si le joueur perd toutes ses vies.\n");
    printf("-Les scores sont calcules en fonction du temps restant.\n");
    printf("Bon jeu !\n");
    printf("---------------------------------------------------------------------\n");
    printf("\nRevenir au menu ?\n\n  1.Oui");
    scanf("%d",&a);
    switch (a)
    {
        case 1:
        {
            Effacer_ecran();
            Affichage_M();
        }
    }
}
