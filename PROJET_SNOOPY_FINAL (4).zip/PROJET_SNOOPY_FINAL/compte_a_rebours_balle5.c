#include "header.h"

void compteARebours5()
{
    Sleep(200);
    Partie.temps--;
    Balle();

}