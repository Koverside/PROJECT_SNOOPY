#include "header.h"


//Mot de passe de chaque niveau
const char* MDP1[] = {"WOIPPY_CITY", "KANYE_WEST", "KYLIAN_MBOUTOU_LOTTIN","WEMBY","KEVIN_DURANT"};

// Déclaration objets
char map[HAUTEUR][LARGEUR] =
{
    "NNNNNNNNNNNNNNNNNNNN",
    "NO  #             ON",
    "N   #    ^   ^     N",
    "N   #  P  ^ ^      N",
    "N##C#      ^       N",
    "N                  N",
    "N?                 N",
    "N############C#####N",
    "NO                ON",
    "NNNNNNNNNNNNNNNNNNNN",
};

