#include "header.h"

void Pause(char utilisateur[]) {
    char choix;
    while (1) {
            choix = getchar();
            Effacer_ecran();
            printf("            PAUSE\n\nR.Reprendre\nQ.Quitter\nT.Sauvegarder");

            if (choix == 'r') {
                // Reprendre le jeu
                Effacer_ecran();
                    printf("Chargement du jeu.");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Chargement du jeu..");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Chargement du jeu...");
                    Sleep(500);
                    Effacer_ecran();

                flag_Pause=FALSE;
                break; // Sortir de la boucle de pause
            }
            else if (choix == 'q')
            {
                // Quitter le jeu
                Effacer_ecran();
                    printf("Fermeture du jeu.");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Fermeture du jeu..");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Fermeture du jeu...");
                    Sleep(500);
                    Effacer_ecran();
                exit(0);
            }
            else if (choix == 't')
            {
                //WaitForSingleObject(mutexCompteARebours, INFINITE);
                Effacer_ecran();
                    printf("Sauvegarde en cours.");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Sauvegarde en cours..");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Sauvegarde en cours...");
                    Sleep(500);
                    Effacer_ecran();
                Sauvegarde(utilisateur);
                //Sauvegarder(map[HAUTEUR][LARGEUR], utilisateur);
                //ReleaseMutex(mutexCompteARebours);
            }
    }
}