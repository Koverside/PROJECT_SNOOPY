#include "header.h"

int Niveau3(char utilisateur[])
{
    srand(time(NULL));
    initializePartie_3(utilisateur);

    Color(4,0);

    Partie.Snoopy_X = HAUTEUR / 2;
    Partie.Snoopy_Y = LARGEUR / 2;
    map[Partie.Snoopy_X][Partie.Snoopy_Y] = SNOOPY;

    affichage();

    _beginthread((_beginthread_proc_type)compteARebours, 0, (void*)&Partie.temps);

    while (Partie.vies > 0)
    {
        if (flag_Pause==FALSE)
        {
            char mouvement = _getch();
            //WaitForSingleObject(mutexCompteARebours, INFINITE);  // Attend que le mutex soit disponible
            Position(mouvement,utilisateur);
            //ReleaseMutex(mutexCompteARebours);  // Libère le mutex
            affichage();
            printf("%d",flag_Pause);
        }
    }
    _endthread();
}
