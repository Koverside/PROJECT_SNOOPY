#include "header.h"


void Position(char mouvement,char utilisateur[])
{
    int Snoopy2_X = Partie.Snoopy_X; //Ancienne position snoopy x
    int Snoopy2_Y = Partie.Snoopy_Y; //Ancienne position snoopy y
    map[Snoopy2_X][Snoopy2_Y] = RIEN;

    switch (mouvement){
        case 'r':
            if (map[Partie.Snoopy_X + 1][Partie.Snoopy_Y] == B_CASSABLE) {
                map[Partie.Snoopy_X + 1][Partie.Snoopy_Y] = RIEN;
            } else if (map[Partie.Snoopy_X - 1][Partie.Snoopy_Y] == B_CASSABLE) {
                map[Partie.Snoopy_X - 1][Partie.Snoopy_Y] = RIEN;
            } else if (map[Partie.Snoopy_X][Partie.Snoopy_Y + 1] == B_CASSABLE) {
                map[Partie.Snoopy_X][Partie.Snoopy_Y + 1] = RIEN;
            } else if (map[Partie.Snoopy_X][Partie.Snoopy_Y - 1] == B_CASSABLE) {
                map[Partie.Snoopy_X][Partie.Snoopy_Y - 1] = RIEN;
            }
            break;
        case 'q':
            if (Partie.Snoopy_Y > 1 && map[Partie.Snoopy_X][Partie.Snoopy_Y - 1] != B_FIXE &&
                map[Partie.Snoopy_X][Partie.Snoopy_Y - 1] != B_CASSABLE) {
                if (map[Partie.Snoopy_X][Partie.Snoopy_Y - 1] == B_PIEGER) {
                    Partie.vies--; //Piege = -1 vies
                    Partie.Snoopy_X = HAUTEUR / 2;
                    Partie.Snoopy_Y = LARGEUR / 2;
                }else if (map[Partie.Snoopy_X][Partie.Snoopy_Y - 1] == B_BONNUS) {
                    Partie.vies++;
                    Partie.Snoopy_Y--;
                }else if (map[Partie.Snoopy_X][Partie.Snoopy_Y - 1] == B_POUSSABLE &&
                          map[Partie.Snoopy_X][Partie.Snoopy_Y - 2] != B_BALLE &&
                          map[Partie.Snoopy_X][Partie.Snoopy_Y - 2] != B_PIEGER &&
                          map[Partie.Snoopy_X][Partie.Snoopy_Y - 2] != B_FIXE &&
                          map[Partie.Snoopy_X][Partie.Snoopy_Y - 2] != B_POUSSABLE &&
                          map[Partie.Snoopy_X][Partie.Snoopy_Y - 2] != OISEAUX &&
                          map[Partie.Snoopy_X][Partie.Snoopy_Y - 2] != B_CASSABLE &&
                          map[Partie.Snoopy_X][Partie.Snoopy_Y - 2] != B_BORDURE &&
                          map[Partie.Snoopy_X][Partie.Snoopy_Y - 2] != B_BONNUS) {
                    map[Partie.Snoopy_X][Partie.Snoopy_Y - 2] = B_POUSSABLE;
                    map[Partie.Snoopy_X][Partie.Snoopy_Y] = RIEN;
                    Partie.Snoopy_Y--;
                } else if (map[Partie.Snoopy_X][Partie.Snoopy_Y - 1] != B_POUSSABLE) {
                    Partie.Snoopy_Y--;
                }
            }
            break;
        case 'd':
            if (Partie.Snoopy_Y < LARGEUR - 2 && map[Partie.Snoopy_X][Partie.Snoopy_Y + 1] != B_FIXE &&
                map[Partie.Snoopy_X][Partie.Snoopy_Y + 1] != B_CASSABLE) {
                if (map[Partie.Snoopy_X][Partie.Snoopy_Y + 1] == B_PIEGER) {
                    Partie.vies--; //Piege = -1 vies
                    Partie.Snoopy_X = HAUTEUR / 2;
                    Partie.Snoopy_Y = LARGEUR / 2;
                }else if (map[Partie.Snoopy_X][Partie.Snoopy_Y + 1] == B_BONNUS) {
                    Partie.vies++;
                    Partie.Snoopy_Y++;
                } else if (map[Partie.Snoopy_X][Partie.Snoopy_Y + 1] == B_POUSSABLE &&
                           map[Partie.Snoopy_X][Partie.Snoopy_Y + 2] != B_BALLE &&
                           map[Partie.Snoopy_X][Partie.Snoopy_Y + 2] != B_PIEGER &&
                           map[Partie.Snoopy_X][Partie.Snoopy_Y + 2] != B_FIXE &&
                           map[Partie.Snoopy_X][Partie.Snoopy_Y + 2] != B_POUSSABLE &&
                           map[Partie.Snoopy_X][Partie.Snoopy_Y + 2] != OISEAUX &&
                           map[Partie.Snoopy_X][Partie.Snoopy_Y + 2] != B_CASSABLE &&
                           map[Partie.Snoopy_X][Partie.Snoopy_Y + 2] != B_BORDURE &&
                           map[Partie.Snoopy_X][Partie.Snoopy_Y + 2] != B_BONNUS) {
                    map[Partie.Snoopy_X][Partie.Snoopy_Y + 2] = B_POUSSABLE;
                    map[Partie.Snoopy_X][Partie.Snoopy_Y] = RIEN;
                    Partie.Snoopy_Y++;
                } else if (map[Partie.Snoopy_X][Partie.Snoopy_Y + 1] != B_POUSSABLE) {
                    Partie.Snoopy_Y++;
                }
            }
            break;
        case 's':
            if (Partie.Snoopy_X < HAUTEUR - 2 && map[Partie.Snoopy_X + 1][Partie.Snoopy_Y] != B_FIXE &&
                map[Partie.Snoopy_X + 1][Partie.Snoopy_Y] != B_CASSABLE) {
                if (map[Partie.Snoopy_X + 1][Partie.Snoopy_Y] == B_PIEGER) {
                    Partie.vies--; //Piege = -1 vies
                    Partie.Snoopy_X = HAUTEUR / 2;
                    Partie.Snoopy_Y = LARGEUR / 2;
                }else if (map[Partie.Snoopy_X + 1][Partie.Snoopy_Y] == B_BONNUS) {
                    Partie.vies++;
                    Partie.Snoopy_X++;
                } else if (map[Partie.Snoopy_X + 1][Partie.Snoopy_Y] == B_POUSSABLE &&
                           map[Partie.Snoopy_X + 2][Partie.Snoopy_Y] != B_BALLE &&
                           map[Partie.Snoopy_X + 2][Partie.Snoopy_Y] != B_PIEGER &&
                           map[Partie.Snoopy_X + 2][Partie.Snoopy_Y] != B_FIXE &&
                           map[Partie.Snoopy_X + 2][Partie.Snoopy_Y] != B_POUSSABLE &&
                           map[Partie.Snoopy_X + 2][Partie.Snoopy_Y] != OISEAUX &&
                           map[Partie.Snoopy_X + 2][Partie.Snoopy_Y] != B_CASSABLE &&
                           map[Partie.Snoopy_X + 2][Partie.Snoopy_Y] != B_BORDURE &&
                           map[Partie.Snoopy_X + 2][Partie.Snoopy_Y] != B_BONNUS) {
                    map[Partie.Snoopy_X + 2][Partie.Snoopy_Y] = B_POUSSABLE;
                    map[Partie.Snoopy_X][Partie.Snoopy_Y] = RIEN;
                    Partie.Snoopy_X++;
                } else if (map[Partie.Snoopy_X + 1][Partie.Snoopy_Y] != B_POUSSABLE) {
                    Partie.Snoopy_X++;
                }
            }
            break;
        case 'z':
            if (Partie.Snoopy_X > 1 && map[Partie.Snoopy_X - 1][Partie.Snoopy_Y] != B_FIXE &&
                map[Partie.Snoopy_X - 1][Partie.Snoopy_Y] != B_CASSABLE) {
                if (map[Partie.Snoopy_X - 1][Partie.Snoopy_Y] == B_PIEGER) {
                    Partie.vies--; //Piege = -1 vies
                    Partie.Snoopy_X = HAUTEUR / 2;
                    Partie.Snoopy_Y = LARGEUR / 2;
                }else if (map[Partie.Snoopy_X + 1][Partie.Snoopy_Y] == B_BONNUS) {
                    Partie.vies++;
                    Partie.Snoopy_X--;
                } else if (map[Partie.Snoopy_X - 1][Partie.Snoopy_Y] == B_POUSSABLE &&
                           map[Partie.Snoopy_X - 2][Partie.Snoopy_Y] != B_BALLE &&
                           map[Partie.Snoopy_X - 2][Partie.Snoopy_Y] != B_PIEGER &&
                           map[Partie.Snoopy_X - 2][Partie.Snoopy_Y] != B_FIXE &&
                           map[Partie.Snoopy_X - 2][Partie.Snoopy_Y] != B_POUSSABLE &&
                           map[Partie.Snoopy_X - 2][Partie.Snoopy_Y] != OISEAUX &&
                           map[Partie.Snoopy_X - 2][Partie.Snoopy_Y] != B_CASSABLE &&
                           map[Partie.Snoopy_X - 2][Partie.Snoopy_Y] != B_BORDURE &&
                           map[Partie.Snoopy_X - 2][Partie.Snoopy_Y] != B_BONNUS) {
                    map[Partie.Snoopy_X - 2][Partie.Snoopy_Y] = B_POUSSABLE;
                    map[Partie.Snoopy_X][Partie.Snoopy_Y] = RIEN;
                    Partie.Snoopy_X--;
                } else if (map[Partie.Snoopy_X - 1][Partie.Snoopy_Y] != B_POUSSABLE) {
                    Partie.Snoopy_X--;
                }
            }
            break;
        case 'p':
            Effacer_ecran();
            flag_Pause=TRUE;
            Pause(utilisateur);
            break;
    }
    if (map[Partie.Snoopy_X][Partie.Snoopy_Y] == OISEAUX)
    {
        Partie.oiseaux_recup++; // -1 oiseaux
        map[Partie.Snoopy_X][Partie.Snoopy_Y] = SNOOPY;
        if (Partie.oiseaux_recup == Partie.nb_oiseaux)
        {
            Partie.score+=Partie.temps*100;
            printf("Votre score est de : %d",Partie.score);
            Sleep(3000);
            switch (Partie.niv)
            {
                case 1:
                    flag_Temps=FALSE;
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant.");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant..");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant...");
                    Sleep(500);
                    Niveau2(utilisateur);
                    break;
                case 2:
                    flag_Temps=FALSE;
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant.");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant..");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant...");
                    Sleep(500);
                    Niveau3(utilisateur);
                    break;
                case 3:
                    flag_Temps=FALSE;
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant.");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant..");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant...");
                    Sleep(500);
                    Niveau4(utilisateur);
                    break;
                case 4:
                    flag_Temps=FALSE;
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant.");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant..");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant...");
                    Sleep(500);
                    Niveau5(utilisateur);
                    break;
                case 5:
                    flag_Temps=FALSE;
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant.");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant..");
                    Sleep(500);
                    Effacer_ecran();
                    printf("Téléportation au niveau suivant...");
                    Sleep(500);
                    Niveau3(utilisateur);
                    break;
            }        //Changement de niveau
        }
    }
    map[Partie.Snoopy_X][Partie.Snoopy_Y] = SNOOPY;
    map[Partie.Balle_X][Partie.Balle_Y] = B_BALLE;

    if (Partie.Snoopy_X == Partie.Balle_X && Partie.Snoopy_Y == Partie.Balle_Y)
    {
        Partie.vies = 0;
    }

    if (Partie.vies == 0)
    {
        exit(0);
    }
}
