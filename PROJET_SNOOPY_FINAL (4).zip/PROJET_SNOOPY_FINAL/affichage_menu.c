#include "header.h"

void Affichage_M()
{
    printf("        SNOOPY MAGIC SHOW \n");
    printf(" 1- Regles du jeu \n");
    printf(" 2- Nouvelles partie \n");
    printf(" 3- Reprendre une partie \n");
    printf(" 4- Choix du niveau\n");
    printf(" 5- Scores \n");
    printf(" 6- Quitter \n");
}