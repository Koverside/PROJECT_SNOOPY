#include "header.h"

void MDP(char utilisateur[])
{
    int nv;
    char MDP_Saisie[20];

    printf("\n    Selectionnez votre niveau :\n      1.La foret de la mort\n      2.Le labyrinthe extreme\n      3.La porte infernale\n      4.Le teleporteur vers les cieux\n      5.Le combat final\n");
    scanf("%d", &nv);
    Effacer_ecran();
    if (nv >= 1 && nv <=5)
    {

        printf("Le mot de passe pour le nv %d est : %s\n", nv, MDP1[nv - 1]);
        printf("Entrez le mot de passe pour le nv %d : ", nv);
        scanf("%s", MDP_Saisie);

        if (verifie_MDP(nv, MDP_Saisie))
        {
            printf("Mot de passe correct. Acces au nv %d autorise.\n", nv);
            // Launch the appropriate level
            switch (nv)
            {
                case 1:
                    Niveau1(utilisateur);
                    break;
                case 2:
                    Niveau2(utilisateur);
                    break;
                case 3:
                    Niveau3(utilisateur);
                    break;
                case 4:
                    Niveau4(utilisateur);
                    break;
                case 5:
                    Niveau5(utilisateur);
                    break;
            }
        } else {
            printf("Mot de passe incorrect.\n");
        }
    } else {
        printf("Niveau invalide.\n");
    }
}