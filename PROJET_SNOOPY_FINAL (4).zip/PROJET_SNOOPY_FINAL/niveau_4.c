#include "header.h"

int Niveau4(char utilisateur[])
{
    srand(time(NULL));
    initializePartie_4(utilisateur);

    Color(9,0);

    Partie.Snoopy_X = 8;
    Partie.Snoopy_Y = 18;
    map[Partie.Snoopy_X][Partie.Snoopy_Y] = SNOOPY;

    affichage();

    _beginthread((_beginthread_proc_type)compteARebours, 0, (void*)&Partie.temps);

    while (Partie.vies > 0)
    {
        if (flag_Pause==FALSE)
        {
            char mouvement = _getch();
            //WaitForSingleObject(mutexCompteARebours, INFINITE);  // Attend que le mutex soit disponible
            Position(mouvement,utilisateur);
            //ReleaseMutex(mutexCompteARebours);  // Libère le mutex
            affichage();
            printf("%d",flag_Pause);
        }
    }
    return 0;
}