 #include "header.h"

 void initializePartie_charger(char map_charger[HAUTEUR][LARGEUR])
 {
     for (int i = 0; i < HAUTEUR; i++) {
         strncpy(map[i], map_charger[i], LARGEUR);
     }
 }


//PARTIE 1

void initializePartie_1()
{
    Partie.nb_oiseaux = 4;
    Partie.vies = 3;
    Partie.temps = 120;
    Partie.oiseaux_recup = 0;
    Partie.niv=1;

    Partie.Balle_X = 3;
    Partie.Balle_Y = 6;
    Partie.mode = 2;
    Partie.S_Balle = RIEN;

    char map_1[HAUTEUR][LARGEUR] = {
            "NNNNNNNNNNNNNNNNNNNN",
            "NO  P    ^  C   C ON",
            "N C ^ ^  PP  ^^ C CN",
            "N  ^^  C ^^ C  C ^^N",
            "N ^^ ^ ^  C  C^C C N",
            "N   ^ P ^^  PC  C  N",
            "N?  C^ ^^ C ^^^^^^ N",
            "N  C ^^  C ^ C  ^^ N",
            "NO  C  ^^ ^^ ^^^  ON",
            "NNNNNNNNNNNNNNNNNNNN",
    };

    for (int i = 0; i < HAUTEUR; i++) {
        strncpy(map[i], map_1[i], LARGEUR);
    }
}


//PARTIE 2

void initializePartie_2()
{
    Partie.nb_oiseaux = 4;
    Partie.vies=3;
    Partie.temps = 120;
    Partie.oiseaux_recup = 0;
    Partie.niv=2;

    Partie.Balle_X = 3;
    Partie.Balle_Y = 6;
    Partie.mode=2;
    Partie.S_Balle = RIEN;

    char map_2[HAUTEUR][LARGEUR] =
    {
            "NNNNNNNNNNNNNNNNNNNN",
            "NO  #             ON",
            "N # #C#############N",
            "N # #              N",
            "N # ##############CN",
            "N # #              N",
            "N # #C#############N",
            "N # #  P #  P  #   N",
            "NO  P #  P  #     ON",
            "NNNNNNNNNNNNNNNNNNNN",
    };

    for (int i = 0; i < HAUTEUR; i++) {
        strncpy(map[i], map_2[i], LARGEUR);
    }
}


//PARTIE 3

void initializePartie_3()
{
    Partie.nb_oiseaux = 4;
    Partie.vies=3;//
    Partie.temps = 120;//
    Partie.oiseaux_recup = 0;//
    Partie.niv=3;//

    Partie.Balle_X = 8;//
    Partie.Balle_Y = 5;//
    Partie.mode = 2;
    Partie.S_Balle = RIEN;

    char map_3[HAUTEUR][LARGEUR] = {
            "NNNNNNNNNNNNNNNNNNNN",
            "NO # #    C     # ON",
            "N  CP#    ^^^^^ ##CN",
            "N###C#PPPP^   ^    N",
            "N             ^^^^ N",
            "N   ^ ^          ^ N",
            "N####P#      #### PN",
            "N  #  #      ^     N",
            "NO C  #      ^    ON",
            "NNNNNNNNNNNNNNNNNNNN",
    };

    for (int i = 0; i < HAUTEUR; i++) {
        strncpy(map[i], map_3[i], LARGEUR);
    }
}

void initializePartie_4()
{
    Partie.nb_oiseaux = 4;
    Partie.vies=3;//
    Partie.temps = 120;//
    Partie.oiseaux_recup = 0;//
    Partie.niv=4;//

    Partie.Balle_X = 7;//
    Partie.Balle_Y = 5;//
    Partie.mode = 3;
    Partie.S_Balle = RIEN;

    char map_4[HAUTEUR][LARGEUR] = {
            "NNNNNNNNNNNNNNNNNNNN",
            "NO O               N",
            "N################# N",
            "NO^    ^   ^   ^   N",
            "N    ^   ^   ^     N",
            "N##P###############N",
            "N  P CC C #?#CCC # N",
            "NOPPCC  PP  #   P  N",
            "N C  C     P   CC  N",
            "NNNNNNNNNNNNNNNNNNNN",
    };

    for (int i = 0; i < HAUTEUR; i++) {
        strncpy(map[i], map_4[i], LARGEUR);
    }
}

void initializePartie_5()
{
    Partie.nb_oiseaux = 4;
    Partie.vies=3;//
    Partie.temps = 120;//
    Partie.oiseaux_recup = 0;//
    Partie.niv=5;//

    Partie.Balle_X = 7;//
    Partie.Balle_Y = 5;//
    Partie.mode = 3;
    Partie.S_Balle = RIEN;

    char map_5[HAUTEUR][LARGEUR] = {
            "NNNNNNNNNNNNNNNNNNNN",
            "N                  N",
            "N                  N",
            "N                  N",
            "N                  N",
            "N                  N",
            "N                  N",
            "N                  N",
            "N                  N",
            "NNNNNNNNNNNNNNNNNNNN",
    };

    for (int i = 0; i < HAUTEUR; i++) {
        strncpy(map[i], map_5[i], LARGEUR);
    }
}




