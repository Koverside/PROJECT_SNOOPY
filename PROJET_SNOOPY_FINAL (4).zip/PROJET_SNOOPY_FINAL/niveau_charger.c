#include "header.h"

int Niveau_charger(char utilisateur[],char map_charger[HAUTEUR][LARGEUR])
{
    srand(time(NULL));
    initializePartie_charger(map_charger);
    Color(9,0);
    map[Partie.Snoopy_X][Partie.Snoopy_Y] = SNOOPY;
    affichage();
    _beginthread((_beginthread_proc_type)compteARebours, 0, (void*)&Partie.temps);

    while (Partie.vies > 0)
    {
        if (flag_Pause==FALSE)
        {
            char mouvement = _getch();
            //WaitForSingleObject(mutexCompteARebours, INFINITE);  // Attend que le mutex soit disponible
            Position(mouvement,utilisateur);
            //ReleaseMutex(mutexCompteARebours);  // Libère le mutex
            affichage();
            printf("%d",flag_Pause);
        }
    }
    return 0;
}