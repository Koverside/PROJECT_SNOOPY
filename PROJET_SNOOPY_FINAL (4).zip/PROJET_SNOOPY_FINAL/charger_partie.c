#include "header.h"

void chargerPartie(char nomUtilisateur, char map[LARGEUR][HAUTEUR])
{
    char chemin_MAP[MAX];
    char chemin_INFO[MAX];
    int choix;
    Effacer_ecran();
    printf("Voulez-vous charger une partie ?\n1.Oui\n2.Non\n");
    scanf("%d", &choix);

    switch (choix)
    {
        case 1:
        {
            Effacer_ecran();

            printf("Saisir votre nom d'utilisateur\n");
            scanf("%s", &nomUtilisateur);

            sprintf(chemin_MAP,"../sauvegarde_MAP/%s_MAP.txt",&nomUtilisateur);

            FILE *fichierMAP = fopen(chemin_MAP, "r");
            if (fichierMAP != NULL)
            {
                int i = 0;
                while (fgets(*map, LARGEUR+1, fichierMAP) != NULL)
                {
                    i++;
                    printf("%s",*map);
                }
                fclose(fichierMAP);
            }
            else
            {
                Effacer_ecran();
                printf("Il n'y a pas de partie enregistrée sous le nom de [%s]\n", &nomUtilisateur);
                Sleep(3000);
                Effacer_ecran();
                printf("Retour au menu principal.");
                Sleep(500);
                Effacer_ecran();
                printf("Retour au menu principal..");
                Sleep(500);
                Effacer_ecran();
                printf("Retour au menu principal..");
                Sleep(500);
            }
            // Sauvegarde données
            printf("juiferie");
            Sleep(1000);
            sprintf(chemin_INFO,"../sauvegarde_INFO/%s_INFO.txt",&nomUtilisateur);
            printf("juiferie");
            Sleep(1000);
            FILE *fichierINFO = fopen(chemin_INFO, "r");
            printf("juiferie");
            Sleep(1000);
            fscanf(fichierINFO, "%d\n%d\n%d\n%d\n%d\n%s\n%d\n%d\n%d\n%d\n%d\n%d\n",
                    &Partie.Snoopy_X,&Partie.Snoopy_Y,&Partie.Balle_X,&Partie.Balle_Y,&Partie.mode,&Partie.S_Balle,
                    &Partie.nb_oiseaux,&Partie.vies,&Partie.temps,&Partie.niv,&Partie.score,&Partie.oiseaux_recup);
            printf("juiferie");
            Sleep(1000);
            fclose(fichierINFO);
            printf("juiferie");
            Sleep(1000);
        }
        case 2:
            Effacer_ecran();
            break;

        default:
            break;
    }
}