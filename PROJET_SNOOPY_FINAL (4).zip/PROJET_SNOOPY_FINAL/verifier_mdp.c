#include "header.h"

int verifie_MDP(int niveau, const char* MDP_Saisie)
{
    if (strcmp(MDP_Saisie, MDP1[niveau - 1]) == 0)
    {
        return 1;
    } else {
        return 0;
    }
}
