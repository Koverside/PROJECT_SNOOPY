#include "header.h"

void Sauvegarde(char nomUtilisateur[MAX])
{
    char chemin_MAP [MAX];
    char chemin_INFO [MAX];
    int choix2=2;
    char KevinDurant[MAX]="KD";
    if (strcmp(nomUtilisateur,KevinDurant) == 0)
    {
        while(choix2==2)
        {
            printf("Veuillez entrer votre nom \nd'utilisateur (sans espace) :\n");
            scanf("%s", nomUtilisateur);
            sprintf(chemin_MAP,"../sauvegarde_MAP/%s_MAP.txt",nomUtilisateur);
            FILE* fichierMAP = fopen(chemin_MAP, "r");
            if (fichierMAP != NULL)
            {
                Effacer_ecran();
                printf("Ce nom d'utilisateur est deja utilise,\netes vous sur de vouloir supprimer la\nsauvegarde precedement faite sur\nce nom d'utilisateur ?\n\n       1.Oui\n       2.Non\n");
                scanf("%d", &choix2);
                fclose(fichierMAP);
            }
            else
            {
                choix2=1;
                sprintf(chemin_MAP,"../sauvegarde_MAP/%s_MAP.txt",nomUtilisateur);
            }
        }
    }
    else
    {
        sprintf(chemin_MAP,"../sauvegarde_MAP/%s_MAP.txt",nomUtilisateur);
    }

    //Sauvegarde MAP

    FILE* fichierMAP = NULL;
    fichierMAP = fopen(chemin_MAP,"w+");
    for (int i=0; i < HAUTEUR ; i++)
    {
        for(int j=0; j < LARGEUR ; j++)
        {
            fprintf(fichierMAP,"%c",map[i][j]);
        }
        fprintf(fichierMAP,"\n");
    }
    fclose(fichierMAP);

//Sauvegarde Informations

sprintf(chemin_INFO,"../sauvegarde_INFO/%s_INFO.txt",nomUtilisateur);
FILE* fichierINFO = NULL;
fichierINFO = fopen(chemin_INFO,"w+");
fprintf(fichierINFO, "%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n",
Partie.Snoopy_X,Partie.Snoopy_Y,Partie.Balle_X,Partie.Balle_Y,Partie.mode,Partie.S_Balle,
Partie.nb_oiseaux,Partie.vies,Partie.temps,Partie.niv,Partie.score,Partie.oiseaux_recup);
fclose(fichierINFO);
}