#include "header.h"

void nouveau(char utilisateur[]) {
    printf("Lancer un nouveau jeu a partir du niveau 1... \n");
    Sleep(1000);
    Niveau1(utilisateur);
    return(Affichage_M());
}