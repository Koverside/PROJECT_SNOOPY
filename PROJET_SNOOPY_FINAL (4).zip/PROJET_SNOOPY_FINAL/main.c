#include "header.h"

HANDLE mutexCompteARebours;
struct Partie Partie;
bool flag_Pause;
bool flag_Temps;


int main()
{
    flag_Pause=FALSE;
    //mutexCompteARebours = CreateMutex(NULL, FALSE, NULL);
    int i;
    bool Menu = true;
    char utilisateur[MAX]="KD";

    do {
        if (Menu)
        {
            Affichage_M();
        }
        printf("Faites votre choix : ");
        scanf("%d", &i);

        switch (i) {
            case 1:
                Effacer_ecran();
                Regles();
                Menu = false;
                break;
            case 2:
                Effacer_ecran();
                nouveau(utilisateur);
                break;
            case 3:
                Effacer_ecran();
                char map_charger[HAUTEUR][LARGEUR];
                chargerPartie(utilisateur[MAX], map_charger);
                Sleep(1000);
                Niveau_charger(utilisateur,map_charger);
                break;
            case 4:
                Effacer_ecran();
                MDP(utilisateur);
                break;
            case 5:
                Effacer_ecran();
                break;
            case 6:
                Effacer_ecran();
                break;
            default:
        }
    }
    while (i != 6);
    return 0;
}